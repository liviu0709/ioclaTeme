#ifndef __FILE__H
#define __FILE__H

int compute(int a, int b, int c);
int check_array(int *vec, int n);
void read_string();

#endif /* __FILE_H__ */

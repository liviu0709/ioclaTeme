#ifndef __FILE__H
#define __FILE__H

int compute(int a, int b);
int check_arrays(int *a, int n, int *b, int m);
void read_string();

#endif /* __FILE_H__ */

#include <stdio.h>

void joey(unsigned int a);
size_t chandler(unsigned int a, unsigned int b);
void ross(unsigned int a, unsigned int b, unsigned int *out, const unsigned char *msg);

static unsigned const char message[30];

int main(void)
{
	unsigned int out[7];
  size_t ret;

	joey(0);
	ret = chandler(0, 0);
	printf("ret: %zu\n", ret);
	ross(0, 0, out, message);

	return 0;
}

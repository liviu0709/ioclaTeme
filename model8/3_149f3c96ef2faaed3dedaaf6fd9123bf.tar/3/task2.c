#include <stdio.h>
#include <stdlib.h>

#define BROKEN_BIT_INDEX 7

// TODO: freestyle starts here, implement Task 2
void task2(void *encrypted_data, int size) {

}

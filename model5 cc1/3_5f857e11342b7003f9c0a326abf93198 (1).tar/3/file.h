#ifndef __FILE__H
#define __FILE__H

int find(int a, int b);
int check_string(char *buf);
void catch_me();

#endif /* __FILE_H__ */